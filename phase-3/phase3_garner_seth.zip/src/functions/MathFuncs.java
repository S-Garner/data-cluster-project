/**
 *   CSCI 4372: Phase 1: Reading Inputs
 *      Author: Seth Garner
 *        Date: <2025-09-02 Tue>
 * Style Guide: [[https:https://www.cs.cornell.edu/courses/JavaAndDS/JavaStyle.html][Cornell University Java Code Style Guidelines]]
 * Description: {
 *                  * Basic math functions used in clustering
 *              }
 */

package functions;
import java.util.List;

public class MathFuncs {

    /*
     * Get the distance between a center and a point
     * @param point  - The data point
     * @param center - The center point
     * @return double - The distance
     */
    public static double getPointDistance(double point, double center) { 
        double distance = point - center; // Get the distance
        return distance * distance;
    }

    /*
     * Get the distance between a center and a point
     * @param center - The center point
     * @param points - The data point
     * @return double - The distance
     */
    public static double getCenterDistance(double[] center, double[] points) {
        double distance = 0.0;

        for (int i = 0; i < center.length; i++) {
            distance += getPointDistance(points[i], center[i]);
        }

        return distance;
    }

}
