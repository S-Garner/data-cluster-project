/**
 *   CSCI 4372: Phase 1: Reading Inputs
 *      Author: Seth Garner
 *        Date: <2025-09-02 Tue>
 * Style Guide: [[https:https://www.cs.cornell.edu/courses/JavaAndDS/JavaStyle.html][Cornell University Java Code Style Guidelines]]
 * Description: {
 *                  * Will grab file from input arg[0]. Will set no_rows && no_columns based on header info
 *                  * Will then pass that information to the appObj. This will store most of the information
 *                  * Will then get datasets and place into appObj for math functions
 *                  * {Cont.}
 *                  * Export Data to file
 *              }
 *     Compile: javac -d out src/*.java {OR} ./build -> Will also run test
 *     Compile (New): javac -d out $(find src -name "*.java")
 *         Run: java -cp out Main {file:filename} {int:no_clusters} {int:no_max_itr} {double:conv_thresh} {int:no_runs}
 */

import java.io.IOException;
import java.util.List;
import java.util.Random;

import data.DataGetter;
import functions.ArgUtils;
import functions.ExportData;
import functions.Runner;
import objects.AppObj;
import objects.RunResult;
import objects.RunSummary;

public class Main {
    public static void main (String[] args) {

        AppObj appObj = ArgUtils.checkArgs(args); // Get Arguments
        AppObj appObj2 = ArgUtils.checkArgs(args);

        if (appObj == null) {                     // Make sure object could be created
            return;
        }

        DataGetter.setRowsAndColumns(appObj);     // Set rows and columns
        DataGetter.setRowsAndColumns(appObj2);

        appObj.setData(DataGetter.normalize(DataGetter.getFullDataSet(appObj)));   // Get Data and set to appObj
        appObj2.setData(DataGetter.normalize(DataGetter.getFullDataSet(appObj2)));
        
        appObj.setCenters(DataGetter.getCenters(appObj));           // Get initial centers and set to appObj
        appObj2.setCenters(DataGetter.randomPartitions(appObj2));   // Get random partitions and set to appObj

        RunSummary summary1 = new RunSummary(); // Create RunSummary objects
        RunSummary summary2 = new RunSummary(); // Create RunSummary objects

        // Run the data clustering
        summary1 = Runner.runnerWithSummary(appObj);
        List<String> runOutput = summary1.getRunOutput(); // Get output from runs
        RunResult bestResult = summary1.getResult();      // Get best result

        // Run the data clustering
        summary2 = Runner.runnerWithSummary(appObj2);
        List<String> runOutput2 = summary2.getRunOutput(); // Get output from runs
        RunResult bestResult2 = summary2.getResult();      // Get best result

        System.out.println(appObj.getFile()); // Print filename

        System.out.println();
        System.out.printf(    // Print best run summary
            "Best Run: %d,Initial SSE: %.6f, Final SSE: %.6f, Iterations: %d\n", 
            bestResult.getRunNumber(), 
            bestResult.getInitialSSE(), 
            bestResult.getFinalSSE(), 
            bestResult.getIterations()
        );

        try
        {
        ExportData.runWriter(appObj, runOutput, 0); // Write to file-output
        } catch (IOException e) {
            System.out.println(e);
        }

        System.out.printf(   // Print best run summary
            "Best Run: %d,Initial SSE: %.6f, Final SSE: %.6f, Iterations: %d\n", 
            bestResult2.getRunNumber(), 
            bestResult2.getInitialSSE(), 
            bestResult2.getFinalSSE(), 
            bestResult2.getIterations()
        );

        try{
        ExportData.runWriter(appObj2, runOutput2, 1); // Write to file-output
        } catch (IOException e) {
            System.out.println(e);
        }

        /*
        try
        {
        ExportData.writer(appObj);                // Write to file-output
        } catch (IOException e) {
            System.out.println(e);
        }
        */

    }
}

/**
 * NOTES FOR LATER:
 * May want to make it to where an object can hold different blocks. A vector of run objects, that way it can have
 * Multiple runs in the same obj
 */
